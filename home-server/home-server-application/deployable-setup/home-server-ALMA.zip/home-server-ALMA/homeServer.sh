#!/bin/bash

#Run the application
java -jar HomeServer.jar
